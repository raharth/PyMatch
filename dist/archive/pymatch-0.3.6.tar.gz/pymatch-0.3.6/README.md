# PyTorch_Lib
A collection of different PyTorch wrappers for training neural networks and reinforcement algorithms

## Install
Necessary to monitor the hardware
https://openhardwaremonitor.org/downloads/